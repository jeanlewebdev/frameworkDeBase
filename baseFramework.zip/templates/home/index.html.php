<h1>Accueil du framework de base</h1>


    <div class="border border-dark">

    <p>ici la doc perso supplémentaire</p>
    
    </div>


<a href="" class="btn btn-primary">Acceder à l'examen</a>