<?php

require_once "core/App/autoloading.php";


\App\Kernel::run();


?>
